sudo avrdude -F -V -c usbtiny  -p ATtiny44 -P usb -U flash:w:main.hex
