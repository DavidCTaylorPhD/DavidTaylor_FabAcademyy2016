

avr-gcc -w -Os -DF_CPU=2000000UL -mmcu=attiny44 -c -o main.o main.c

avr-gcc -w -mmcu=attiny44 main.o -o main

avr-objcopy -O ihex -R .eeprom main main.hex
