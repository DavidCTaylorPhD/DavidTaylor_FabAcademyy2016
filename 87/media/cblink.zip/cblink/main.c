/**
This is a super simple program to test the "echo Hello" board from the FabAcademy
The input and output pins on your board may be different.  If so, 
Feel free to change the port numbers to match your design.

I showed a couple of different methods for writing to registers and ports

There are references and notes at the bottom of this page on how to compile
program the chip.  I actually wrote two scripts build.sh and program.sh.  Simply
put these in the same directory as this main file and do't rename any files.

To compile, run:
$  ./build.sh

To download using AVRdude, run:
$  ./program.sh

 The LED should flash on and off ever second.
*/
#include <avr/io.h>
#include <util/delay.h>

int main (void)
{


//On my board, PB2 is a button that relies on the internal pull-up resistor in the ATtiny (active low)
//PA7 is an active high LED


// make PA7 an output by directly writing a '1' to the direction register
DDRA = 0b10000000; 


while(1){
    // statement

    //sets the specific bit to a 1  0x80 = 0b10000000, PA7
//  PORTA = 0x80; //You could directly write a numeric value to the entire port
 PORTA |= (1 << PA7);   //another common way to turn on an output, OR it with '1'

_delay_ms(1000); // Delay 1000ms

//  PORTA = 0;   //you could write directly to the port
 PORTA &= ~(1 << PA7);  //another common way to turn the LED off, AND it with '0'
_delay_ms(1000); // delay 1000ms
}

 return 0;
}




/**
You need to install all the AVR tools first:
sudo apt-get install gcc-avr binutils-avr gdb-avr avr-libc avrdude


This is how you build and download this blinky program:

avr-gcc -w -Os -DF_CPU=2000000UL -mmcu=attiny44 -c -o main.o main.c

avr-gcc -w -mmcu=attiny44 main.o -o main

avr-objcopy -O ihex -R .eeprom main main.hex

Now plug it in to your FabISP, and Also plug it in to the FTDI port.  The FTDI is there to provide power to the chip, otherwise you won't be able to program.

sudo avrdude -F -V -c usbtiny  -p ATtiny44 -P usb -U flash:w:main.hex




References:
http://www.embedds.com/controlling-avr-io-ports-with-avr-gcc/

http://www.avrfreaks.net/index.php?name=PNphpBB2&file=viewtopic&t=37871

How to compile and send: http://www.swharden.com/blog/2013-01-06-avr-programming-in-linux/

bit shifting to write and read: http://www.embedds.com/controlling-avr-io-ports-with-avr-gcc/

*/
